package com.Trainee.TraineeMgmt.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Trainee.TraineeMgmt.model.Login;


public interface LoginRepository extends JpaRepository<Login, Integer> {

}
