package com.Trainee.TraineeMgmt.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.Trainee.TraineeMgmt.model.Login;
import com.Trainee.TraineeMgmt.model.Trainee;

public interface TraineeRepository extends JpaRepository<Trainee, Integer> {

	void saveAndFlush(Login log);

	
   


}
