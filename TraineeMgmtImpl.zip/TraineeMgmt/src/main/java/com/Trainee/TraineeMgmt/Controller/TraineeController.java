package com.Trainee.TraineeMgmt.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;


import com.Trainee.TraineeMgmt.model.Trainee;

import com.Trainee.TraineeMgmt.service.TraineeService;


@Controller
public class TraineeController {
    @Autowired
	TraineeService service;
    

    @RequestMapping("/home")
	public String home() {
		System.out.println("inside home");
		return "home";
	}
   /* @RequestMapping("/login")
	public String checkCredentials(String userName,String pass)
	{
		if(userName.equals("admin")&& pass.equalsIgnoreCase("admin"))
		{
			return "home";
		}
		else
		{
			return "Please check the enter credentials";
		}
	
	}*/
	
    @RequestMapping("/login")
   	public String login() {
   		System.out.println("inside login");
   		return "login";
   	}
    @RequestMapping(value="/addTrainee", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
	  
	  //ModelAndView mav = new ModelAndView("addEmp");
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("addTrainee"); mav.addObject("trainee", new Trainee()); 
		  return mav; 
	  }
    
	@RequestMapping(value="/addTrainee", method=RequestMethod.POST)
	public ModelAndView addEmployee(@ModelAttribute("trainee") Trainee tr) {
		
		service.insertTrainee(tr);
		ModelAndView mav = new ModelAndView("addTrainee");
		String message = "Trainee Added Successfully "+tr.getTraineeId();
		mav.addObject("successMessage", message);
		return mav;
	}
	
	@RequestMapping(value="/deleteTrainee", method=RequestMethod.GET)
	public ModelAndView loadTraineeById() {			
		ModelAndView mav = new ModelAndView("deleteTrainee");	
		mav.addObject("trainee", new Trainee()); 
		return mav;
	}
	
	@RequestMapping(value="/deleteTrainee", method=RequestMethod.POST)
	public ModelAndView deleteEmployeeId(@RequestParam Integer traineeId,@ModelAttribute("trainee") Trainee tr)
	{
		Trainee trainee = service.findTrainee(traineeId);
		System.out.println("found = "+trainee);
		ModelAndView mav = new ModelAndView("deleteTrainee");
		if(trainee!=null)
		{
			mav.addObject("trainee",trainee);
			service.removeTrainee(traineeId);
		}
		else
	     {
	        	mav.addObject("errorMessage","Employee details not found for the given trainee id");
	    		
	     }
	        
		service.removeTrainee(traineeId);
		System.out.println("delete operation");
	    return mav;
	
		
	}
	@RequestMapping(value="/updateTrainee", method=RequestMethod.GET)
	public ModelAndView loadUEmployeeById() {			
		ModelAndView mav = new ModelAndView("updateTrainee");
		mav.addObject("trainee", new Trainee()); 
		return mav;
	}
	
	@RequestMapping(value="/updateTrainee", method=RequestMethod.POST)
	public ModelAndView updateEmployeeId( Trainee trainee,@RequestParam Integer traineeId)
	{
	    Trainee trainee2=service.findTrainee(traineeId);
		System.out.println("found = "+trainee2);
		ModelAndView mav = new ModelAndView("updateTrainee");
		
		
			
	        if (trainee2==null) {
	        	mav.addObject("errorMessage","Employee details not found for the given employee id");
	    		
	        }
	        
	        Trainee tr=service.updatePartially(trainee2,traineeId);
		   System.out.println("update operation");
		  		   System.out.println("update operation");
	       return mav;
	
		
	}
	 /* @RequestMapping(value="/login", method=RequestMethod.GET) 
	  public  ModelAndView loadAddEmployee() {
	  
	  //ModelAndView mav = new ModelAndView("addEmp");
		  ModelAndView mav = new ModelAndView(); 
		  mav.setViewName("login");
		  mav.addObject("login", new Login()); 
		  return mav; 
	  }
	  @RequestMapping(value="/login", method=RequestMethod.POST)
		public ModelAndView addEmployee( Login log) {
			
			service.doLogin(log);
			ModelAndView mav = new ModelAndView("login");
			String message = "Trainee login Successfully";
			mav.addObject("successMessage", message);
			return mav;
		}*/
	@RequestMapping(value="/dispTraineeById", method=RequestMethod.GET)
	public ModelAndView loadGetEmployeeById() {			
		ModelAndView mav = new ModelAndView("dispTraineeById");		
		return mav;
	}
	
	@RequestMapping(value="/dispTraineeById", method=RequestMethod.POST)
	public ModelAndView getEmployeeById(@RequestParam Integer traineeId) {
		Trainee tr = service.findTrainee(traineeId);
		System.out.println("found = "+tr);
		ModelAndView mav = new ModelAndView("dispTraineeById");	
		if(tr!=null) {
			mav.addObject("trainee", tr);
		}
		else
			mav.addObject("errorMessage","trainee details not found ");
		
		return mav;
	}
	@RequestMapping(value="/displayTrainee", method=RequestMethod.GET)
	public ModelAndView getEmloyees() {
		List<Trainee> list = service.getTrainees();
		ModelAndView mav = new ModelAndView("displayTrainee");
		if(list.isEmpty()) {
			mav.addObject("errorMessage", "Trainee details not found");			
		}
		else {
			mav.addObject("traineeList",list);			
		}
		
		return mav;
	}

}
